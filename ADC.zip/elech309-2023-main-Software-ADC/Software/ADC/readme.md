# ADC et DAC

## ADC-DAC1.X

Illustre l'utilisation de l'ADC interne avec déclenchement manuel

## ADC-DAC2

Illustre l'utilisation de l'ADC interne avec déclenchement automatique par le timer3

## [Oscilloscope](/oscilloscope.md)

Exemple de projet utilisant l'ADC et l'UART pour réaliser un oscilloscope numérique minimaliste
